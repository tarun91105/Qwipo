import {Route, Switch} from 'react-router-dom'

import Home from './components/Home'
import NotFound from './components/NotFound'
import UpdateProfile from './components/UpdateProfile'
import ReadProfile from './components/ReadProfile'
import CreateProfile from './components/CreateProfile'
import Success from './components/Success'

import './App.css'

const App = () => (
  <Switch>
    <Route exact path="/" component={Home} />
    <Route exact path="not-found" component={NotFound} />
    <Route exact path="/update-profile" component={UpdateProfile} />
    <Route exact path="/create-profile" component={CreateProfile} />
    <Route exact path="/read-profile" component={ReadProfile} />
    <Route exact path="/success" component={Success} />
  </Switch>
)

export default App
